import React from 'react'

const Person = (props) => {
    return(
        <li>{props.name} - {props.num}</li>
    )
}

export default Person