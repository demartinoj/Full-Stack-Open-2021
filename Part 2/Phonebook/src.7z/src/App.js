import React, { useState } from 'react'
import Person from './components/Person'

const App = () => {

/// STATE DECLARATIONS ///
  const [ persons, setPersons ] = useState([
    { name: 'Arto Hellas', id: 'Arto Hellas', num: '123 456 789'}
  ]) 
  const [ newName, setNewName ] = useState('Add a new person')
  const [ number, setNumber ] = useState('Add a new number')




/// ADD NAME COMPONENTS ///

  //addName returns event
  const addName = (event) => {
    event.preventDefault()
    //Declares new nameObject w/ properties name, date, and id
    const nameObject = {
      content: newName,
      id: newName,
      num: number,
    }

    //dupeLogic function handles the logic for detecting a duplicate entry or adding valid entry
    const dupeLogic = () => {
      const namesArray = persons.map((entry) => {return(entry.id.toLowerCase())})
      let dupeState = namesArray.includes(nameObject.id.toLowerCase())
      console.log(dupeState)
      if (dupeState === true){
        window.confirm(`"${nameObject.id}" is already included in this phonebook`) //string literals use ` not ' 
        setNewName('')
      } else{
        setPersons(persons.concat(nameObject))
        setNewName('')
      }
    }
    dupeLogic()
  }

  //handleNewName function that declares the setNewName as the target.value from html form
  const handleNewName = (event) => {
    // console.log(event.target.value)
    event.preventDefault()
    setNewName(event.target.value)
  }

  //handleNewNumber function that declares the setNumber as the target.value from html form
  const handleNewNumber = (event) => {
    event.preventDefault()
    setNumber(event.target.value)
  }

  const handleSearch = (event) =>{
    event.preventDefault()
    console.log(event.target.value)
  }

/// RETURN RENDER ///
  return (
    <div>
      <h2>Phonebook</h2>
      
      <h3>Search for a contact name </h3>

        <form>
          <input
            onChange = {handleSearch}
            />
            </form> 

      <h3>New Contact entry: </h3>

      <form onSubmit={addName}>
        <input 
          value={newName}
          onChange={handleNewName}
          />
      </form>


      <form onSubmit = {addName}>
        <input
          value = {number}
          onChange = {handleNewNumber}
          />
          <button type="submit"> Add Number </button> 
      </form>

      <h2>Numbers</h2>
      <ul>
        {persons.map((contact) =>
          <Person key={contact.id} name={contact.id} num = {contact.num}/>)}
      </ul>
    </div>
          )
  }
export default App